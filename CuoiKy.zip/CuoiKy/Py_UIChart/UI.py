'''
Created on Oct 13, 2022

@author: anh
'''


import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT as NavigationToolbar
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QInputDialog,QFileDialog, QWidget, QMessageBox
import sys
import os
import UIChart

import numpy as np
import pandas as pd

from threading import *
# from threading import Thread
# import threading
import time

import requests
import json
from cv2 import line

os.system("pyuic5 UIChart.ui -o UIChart.py")
os.system("pyrcc5 Icons.qrc -o Icons_rc.py")


colors = ['red', 'green', 'blue', 'yellow', 'orange', 'aqua', 'purple', 'blueviolet']

class Canvas_1(FigureCanvas):
# Này truyền vào 1 cái mảng 1 chiều trục x, mảng nhiều chiều trục y, mỗi chiều hiển thị cho 1 thông số trên 1 lineline, label là mảng tên từng line.
    def __init__(self, x, y, labels, Title):     
        self.fig , self.ax = plt.subplots(1, dpi=100, figsize=(6, 5), facecolor='white')
        super().__init__(self.fig) 

        self.fig.suptitle(Title, size = 18)
        
        for i in range(len(y)):
            plt.plot(x, y[i], color = colors[i], marker = 'o', label = labels[i])
            
        plt.grid(True)
        plt.xticks(rotation = 30)
        plt.legend()

class Canvas_2(FigureCanvas):
# Này tương tự cái Canvas1 nhưng chỉ có chấm chứ ko hiện đường nối dấu chấm.
    def __init__(self, x, y, labels, Title):     
        self.fig , self.ax = plt.subplots(1, dpi=100, figsize=(6, 5), facecolor='white')
        super().__init__(self.fig) 
        self.fig.suptitle(Title,size = 18)
        plt.grid(True)
        for i in range(len(y)):
            plt.scatter(x, y[i], color = colors[i], marker = 'o', label = labels[i])

        plt.xticks(rotation = 30)
        plt.legend()
    

class Canvas_3(FigureCanvas):
# Này truyền vào 1 cái mảng 1 chiều trục x, mảng nhiều chiều trục y, mỗi chiều hiển thị cho 1 thông số trên 1 bar, label là mảng tên từng bar.
    def __init__(self, x, y, labels, Title):     
        self.fig , self.ax = plt.subplots(1, dpi = 100, figsize = (6, 5), facecolor = 'white')
        super().__init__(self.fig) 

        barWidth = 1
        self.fig.suptitle(Title,size = 18)
        print( "y", y)

        br1 = np.arange(len(y[0]))
        print("y0 = ", len(y[0]))
        br1 *= len(y) + 1 

        print("Length Y: ", len(y))
        print("Br1: ",      br1)

        for i in range(len(y)):
            plt.bar(br1, y[i], width = barWidth, color = colors[i], label = labels[i], edgecolor = 'black')
            br2 = [x + barWidth for x in br1]
            print("br2 = ", br2)
            br1 = br2
            print(br1)
        plt.xticks([(r - (2*barWidth)) for r in br1], x)
        plt.xticks(rotation = 30)

        # plt.grid(True)
        plt.legend()
    
class Canvas_4(FigureCanvas):
    def __init__(self, y, labels, Title):
        self.fig, self.ax = plt.subplots(1, len(y), dpi = 100, figsize = (6, 5), facecolor = 'white')
        super().__init__(self.fig)

        self.fig.suptitle(Title, size = 18)
        print(y)
        for i in range(len(y)):
            # y[i] = np.array(y[i], dtype=np.int32)
            
            self.ax[i].hist(y[i], color = colors[i], align = 'left', edgecolor = 'black', label = labels[i])
            self.ax[i].set_xlabel(labels[i])
        plt.subplots_adjust(wspace=0.3, hspace=0)



from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import traceback, sys

class WorkerSignals(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(tuple)
    result = pyqtSignal(object)
    progress = pyqtSignal(int)


class Worker(QRunnable):
    def __init__(self, fn, *args, **kwargs):
        super(Worker, self).__init__()
        # Store constructor arguments (re-used for processing)
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()
        # Add the callback to our kwargs
        self.kwargs['progress_callback'] = self.signals.progress

    @pyqtSlot()
    def run(self):
        # Retrieve args/kwargs here; and fire processing using them
        try:
            result = self.fn(*self.args, **self.kwargs)
        except:
            traceback.print_exc()
            exctype, value = sys.exc_info()[:2]
            self.signals.error.emit((exctype, value, traceback.format_exc()))
        else:
            self.signals.result.emit(result)  # Return the result of the processing
        finally:
            self.signals.finished.emit()  # Done

arr = [2,3,7,9]

#[{"ThietBi":"Tram1","NhietDo":28.37,"DoAm":66.31,"AnhSang":54,"CO2":480,"Mua":1, "ThoiTiet":1,"ThoiGian":"2022-10-23 14:41:49"}]

class StartUI(QtWidgets.QMainWindow, UIChart.Ui_MainWindow):
    NumShow = 0
    startThreadGetData = 0
    counter = 0

    def __init__(self):
        super(StartUI, self).__init__()
        self.setupUi(self)
        self.Setup()
        self.threadpool = QThreadPool()
        print("Multithreading with maximum %d threads" % self.threadpool.maxThreadCount())

        self.timer = QTimer()
        self.CreateChart()
        self.fileLink = ""
    
    # Hàm tìm và đọc file.   
    def openFileNameDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.fileLink, _ = QFileDialog.getOpenFileName(self,"Choose your data file to view", "", "All Files (*);;Python Files (*.py)", options=options)
        if self.fileLink:
            print(self.fileLink)
            fileName = os.path.basename(self.fileLink)
            print(fileName)
            self.Choosefile_button.setText(fileName)
            
    def CreateChart(self):
        if(self.NumShow != 0):
            self.NumShow = 0
            self.Layout_Chart1.removeWidget(self.grafica1)
            self.Layout_Chart2.removeWidget(self.grafica2)
            self.Layout_Chart3.removeWidget(self.grafica3)
            self.Layout_Chart4.removeWidget(self.grafica4)
# Phần này là random, chỉ để test         
        self.y = []
        self.x = np.arange(0, 20)

        self.y1 = np.random.randint(0, 1, size = 20)
        self.y2 = np.random.randint(0, 1, size = 20)
        self.y3 = np.random.randint(0, 1, size = 20)
        
        self.y.append(self.y1)
        self.y.append(self.y2)
        self.y.append(self.y3)
#################################        
        self.grafica1 = Canvas_1(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], 'Line Chart')
        self.grafica2 = Canvas_2(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], 'Points Chart')
        self.grafica3 = Canvas_3(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], 'Bar Chart')
        self.grafica4 = Canvas_4(self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], "Histogram")

        # print(type(self.grafica1))
        
        self.Layout_Chart1.addWidget(self.grafica1)
        self.Layout_Chart2.addWidget(self.grafica2)
        self.Layout_Chart3.addWidget(self.grafica3)
        self.Layout_Chart4.addWidget(self.grafica4)
        self.NumShow = 1
    def DrawChart(self):
        if(self.NumShow != 0):
            self.NumShow = 0
            self.Layout_Chart1.removeWidget(self.grafica1)
        self.grafica1 = Canvas_1(self.x, self.y, ['NhietDo', 'DoAm'])
        self.Layout_Chart1.addWidget(self.grafica1)
        
    def ThreadGetData(self):
        # while True:
        #     # self.DataLink = self.URL_lineEdit.text()
        #     # print(self.DataLink)

            # if(self.startThreadGetData):
                #url = os.environ["https://nckh.assfa.net/data.php"]
        self.error = 0
        try:
            response = requests.get(str(self.DataLink))
        except:
            print("Get ERROR")
            self.error = 1
        
        if(self.error == 0):
            responseText = str(response.text)
            # responseText = json.loads(responseText)
            # responseText = str(responseText)
            responseText = responseText.replace('[','')
            responseText = responseText.replace(']','')
            responseText = responseText.replace('\n','')
            responseText = responseText.replace('\t','')
            responseText = responseText.replace('\r','')
            
            print("Responce: ", responseText)
            print("Responce Type: ", type(responseText))

            self.Data = json.loads(responseText)
            print("Data: ", self.Data)
            print("Data Type: ", type(self.Data["NhietDo"]))
            
            if(self.NumShow != 0):
                self.NumShow = 0
                self.Layout_Chart1.removeWidget(self.grafica1)
                self.Layout_Chart2.removeWidget(self.grafica2)
                self.Layout_Chart3.removeWidget(self.grafica3)
                self.Layout_Chart4.removeWidget(self.grafica4)

            
            ThoiGian = self.Data["ThoiGian"]
            # print(type(ThoiGian))
            TachThoiGian = ThoiGian.split(':')
            # print(ThoiGian.split(':'))
            NgayGio = TachThoiGian[0] + ':' + TachThoiGian[1]
            print(NgayGio)

            TachThoiGian2 = TachThoiGian[0].split(' ')
            print(TachThoiGian2)

            Time1 = TachThoiGian2[1] + ':' + TachThoiGian[1] + ':' + TachThoiGian[2]
            print(Time1)

            if(self.x[len(self.x) - 1] != Time1):
                self.x = np.delete(self.x, 0)
                self.x = np.append(self.x, Time1)

                self.y[0] = np.delete(self.y[0], 0)
                self.y[0] = np.append(self.y[0], self.Data["NhietDo"])
                # print(self.y[0])

                self.y[1] = np.delete(self.y[1], 0)
                self.y[1] = np.append(self.y[1], self.Data["DoAm"])
                # print(self.y[1])

                self.y[2] = np.delete(self.y[2], 0)
                self.y[2] = np.append(self.y[2], self.Data["AnhSang"])

            # self.grafica1.DrawNew(self.x, self.y, ['NhietDo', 'DoAm', 'AnhSang'], Title)

            self.grafica1 = Canvas_1(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], "Line Chart at: " + NgayGio)
            self.grafica2 = Canvas_2(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], "Points Chart at: " + NgayGio)
            self.grafica3 = Canvas_3(self.x, self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], "Bar Chart at: " + NgayGio)
            self.grafica4 = Canvas_4(self.y, ['NhietDo (°C)', 'DoAm (%)', 'AnhSang (lx)'], "Histogram Chart at: " + NgayGio)
            # self.grafica4 = Canvas_4(self.y[0])
            
            # self.Layout_Chart1.removeWidget(self.grafica1)
            self.Layout_Chart1.addWidget(self.grafica1)
            self.Layout_Chart2.addWidget(self.grafica2)
            self.Layout_Chart3.addWidget(self.grafica3)
            self.Layout_Chart4.addWidget(self.grafica4)
            self.NumShow = 1
            # self.Layout_Chart1.insertWidget(self.grafica1)
            # 
                # print("NhietDo: ", type(self.Data))    
            # time.sleep(1)
    def analys_data(self, df):
        list_day = []                                       # List chứa các chuỗi thời gian.
        for x in df['ThoiGian']:							# Duyệt cột thời gian.
            tmp = x.split(" ")								# Dùng split tách thời gian với ngày giờ với ký tự " ", trả về tmp là list.
            list_day.append(tmp[0])	                        # Thêm ngày tương ứng vào List chưa thời gian.
        # Nhét ngày vào list
        list_day = dict.fromkeys(pd.unique(list_day))		# Chuyển list thời gian thành dict, các ô có cùng ngày chỉ được đặt 1 lần duy nhất vào dict dùng unique.
        tmp = df['ThoiGian'].str.split(" ", expand=True)	# Tách cột Thời gian thành 2 cột ngày và giờ.
        df['ThoiGian'] = tmp.iloc[:, 0]						# Lấy cột ngày (cột 0), gán lại vào cột thời gian. Cột thời gian chỉ còn ngày.
        grouped = df.groupby(df['ThoiGian'])				# Goole cách tách data thành các group các data cùng ngày.
        tmp = {}
        for x in list_day:                                  # Duyệt list ngày.
            tmp[x] = grouped.get_group(x)                   # Lấy từng nhóm data cùng này gán vào dict tmp.

        for x in tmp:										# Google tính trung bình : https://stackoverflow.com/questions/31037298/pandas-get-column-average-mean
            tmp[x] = tmp[x].mean()                          # Tính trung bình từng thông số trong value của tmp.
        return tmp

    def XuLiFile(self):
        print("Xu Li File")
        df1 = pd.read_table(self.fileLink, delimiter=",")
        df1.drop(df1.columns[[0]], axis=1, inplace=True)
        label = []
        for i in df1.columns:
            label.append(i)
        label.remove("ThoiGian")
        print(label)

        data1 = self.analys_data(df1)
        print(type(data1))

        data_x = list(data1.keys())
        print(type(data_x))

        data_y = []
        for i in label:
            data_y.append(np.array([]))
        print(data_y)

        for i in range(0, len(label)):
            print(label[i])
            for j in data_x:
                data_y[i] = np.append(data_y[i], data1[j][label[i]])
            print(len(data_y[i]))

        print(label)
        print(data_x)
        print(data_y)


        if(self.NumShow != 0):
            self.NumShow = 0
            self.Layout_Chart1.removeWidget(self.grafica1)
            self.Layout_Chart2.removeWidget(self.grafica2)
            self.Layout_Chart3.removeWidget(self.grafica3)
            self.Layout_Chart4.removeWidget(self.grafica4)
        

        self.grafica1 = Canvas_1(data_x, data_y, label, "Line Chart")
        self.grafica2 = Canvas_2(data_x, data_y, label, "Points Chart")
        self.grafica3 = Canvas_3(data_x, data_y, label, "Bar Chart")
        self.grafica4 = Canvas_4(data_y, label, "Histogram Chart")

        self.Layout_Chart1.addWidget(self.grafica1)
        self.Layout_Chart2.addWidget(self.grafica2)
        self.Layout_Chart3.addWidget(self.grafica3)
        self.Layout_Chart4.addWidget(self.grafica4)
        self.NumShow = 1


        # print(len(data_x))
        # print(len(data_y[0]))
        # grafica1 = Canvas_1(data_x, data_y, label, 'Line Chart')

        # result = pd.read_table(self.fileLink)
        # print(result)
        # data_top = result.head()
        # print(data_top)
        # print(type(data_top))
        


        
    def Viewbutton_Clicked(self):
        # XỬ lý data, post get lấy data ở đây.
        self.DataLink = self.URL_lineEdit.text()
        print(type(self.DataLink))

        # if(self.startThreadGetData == 0):
        if(self.DataLink != ""):
            if(self.startThreadGetData == 0):
                self.timer.setInterval(1000)
                self.timer.timeout.connect(self.ThreadGetData)
                self.timer.start()
                self.startThreadGetData = 1
            elif(self.startThreadGetData == 1):
                self.startThreadGetData = 0
                self.timer.stop()
        else:
            self.timer.stop()
            if(self.fileLink != ""):
                self.XuLiFile()
            else:
                print("No file link")


        
    def show_warning_quitbox(self):
        self.msg = QMessageBox()
        self.msg.setIcon(QMessageBox.Warning)
        self.msg.setText("Do you want to quit?")
        self.msg.setWindowTitle("Quit now?")
        self.msg.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        retval = self.msg.exec_()
        if retval == QMessageBox.Yes:
            print('Quited application.')

            self.close()
                
    def Setup(self):
        self.Choosefile_button.clicked.connect(self.openFileNameDialog)
        self.View_button.clicked.connect(self.Viewbutton_Clicked)
        self.Quit_button.clicked.connect(self.show_warning_quitbox)
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = StartUI()
    form.show()
    app.exec_()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    