'''
Created on Oct 6, 2022

@author: anh
'''
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import PyQt5

# Read data from file.
file = pd.read_csv("dataASSFA.csv")
file.columns = ["ID", "CO2", "CO", "Temp", "Humi", "LaTi", "LongTi", "Time", "User"]

# Get columns data.
CO2  = file["CO2"]
CO   = file["CO"]
Temp = file["Temp"]
Humi = file["Humi"]
Time = file["Time"]

# Creat boolean filter array.
CO2_Bool  = (CO2  > 400) & (CO2  < 800)
Temp_Bool = (Temp > 20)  & (Temp < 50)
Humi_Bool = (Humi > 20)  & (Humi < 100)

# Filtting for all columns.
CO2 =  CO2[CO2_Bool & Temp_Bool & Humi_Bool]
CO  =  CO [CO2_Bool & Temp_Bool & Humi_Bool]
Temp = Temp[CO2_Bool & Temp_Bool & Humi_Bool]
Humi = Humi[CO2_Bool & Temp_Bool & Humi_Bool]
Time = Time[CO2_Bool & Temp_Bool & Humi_Bool]
print(type(CO2))

# CO2 Chart.
# plt.bar( Time.tolist(), CO2.tolist())
# plt.show()
# CO Chart.
# plt.bar(CO.tolist())
# plt.show()
# Temp Chart.
# plt.plot(Temp.tolist())
# plt.show()
# Humi Chart.
# plt.plot(Humi.tolist())
# plt.show()


